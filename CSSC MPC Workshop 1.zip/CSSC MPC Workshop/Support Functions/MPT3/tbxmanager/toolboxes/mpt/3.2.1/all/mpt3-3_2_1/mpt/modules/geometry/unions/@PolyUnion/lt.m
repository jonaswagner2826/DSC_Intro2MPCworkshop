function status = lt(U1, U2)
% tests whether U1 is a strict subset of U2

error('Not yet implemented.');

end
