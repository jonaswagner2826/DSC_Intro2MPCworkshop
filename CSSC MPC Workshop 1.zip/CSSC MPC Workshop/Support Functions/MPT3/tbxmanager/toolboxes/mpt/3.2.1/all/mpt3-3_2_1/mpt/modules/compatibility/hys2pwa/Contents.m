% Conversion from HYSDEL to PWA
